ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1144039.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': false,
    'powerPreference': "default"
};
SCRIPTS = [ 46653677, 46653627, 46653628, 46653672, 46653676, 46653680, 46653684, 46653685, 46653696, 47922288 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
